package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"time"

	libp2p "github.com/libp2p/go-libp2p"
	"github.com/libp2p/go-libp2p/core/peer"
	"github.com/libp2p/go-libp2p/p2p/discovery/mdns"
)

type notifee struct{}

func (n *notifee) HandlePeerFound(pi peer.AddrInfo) {
	log.Printf("discovered peer: %s\n", pi.ID.ShortString())
}

func main() {
	var (
		useMDNS  = flag.Bool("mdns", true, "use mDNS discovery")
		maxConns = flag.Int("maxconns", 64, "max connections (simulates constrained devices)")
		interval = flag.Duration("interval", 5*time.Second, "logging interval")
	)
	flag.Parse()

	ctx := context.Background()

	// Basic host with default security/mux
	h, err := libp2p.New(libp2p.ResourceManager(nil))
	if err != nil {
		log.Fatal(err)
	}
	defer h.Close()

	// Optional mDNS for local discovery
	if *useMDNS {
		s := mdns.NewMdnsService(h, "peer-discovery-lite", &notifee{})
		if err := s.Start(); err != nil {
			log.Fatal(err)
		}
		defer s.Close()
	}

	ticker := time.NewTicker(*interval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			conns := h.Network().Conns()
			if len(conns) > *maxConns {
				// Naive backpressure: close oldest connections.
				for i := 0; i < len(conns)-*maxConns; i++ {
					conns[i].Close()
				}
			}
			fmt.Printf("[stats] peers=%d conns=%d\n", len(h.Network().Peers()), len(conns))
		case <-ctx.Done():
			return
		}
	}
}
