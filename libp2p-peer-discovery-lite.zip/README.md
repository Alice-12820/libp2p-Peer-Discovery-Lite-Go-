# libp2p Peer Discovery Lite (Go)

Minimal libp2p prototype exploring **peer discovery** strategies suitable for
**low-resource Ethereum validators**. It logs discovered peers and periodic
connectivity stats that could inform DDoS resistance and bootstrapping heuristics.

> This is a learning/prototype repo intended for research and benchmarking.

## What it includes
- Basic libp2p host
- mDNS local discovery (swap for Kademlia if desired)
- Periodic peer table logging
- Flags for connection limits to simulate constrained hardware

## Build & Run
```bash
go mod tidy
go run . -mdns=true -maxconns=64 -interval=5s
```

## Notes
- Swap mDNS for Kademlia DHT for wider-area discovery.
- Consider backoff strategies and scoring to avoid Sybil peaks.
- For Ethereum, integrate with devp2p bootnodes for realistic tests.

## License
MIT
